import React, { Component } from 'react'

 class Usergreet extends Component {
   constructor(props) {
     super(props)
     this.state = {
       isLoggedIn: true
   }
  }
  render() {

    return   this.state.isLoggedIn && <div> Welcome Theju</div>
    /*this.state.isLoggedIn ?
      (<div>Welcome Thejasri</div> ):
     ( <div> Welcome Guest</div>
    )
     
   /* let message
    if(this.state.isLoggedIn) {
      message = <div>Welcome Thejasri </div>
    }
    else {
      message = <div>Welcome Guest</div>
    }
  return <div>{ message}</div>

   /*} if(this.state.isLoggedIn)
    {
      return (
        <div> Welcome Thejasri</div>
      )
    }*/
    /*else{
      <div> Welcome Guest</div>
    }*/
   /*} return (
      <div>
        <div> Welcome Thejasri</div>
        <div> Welcome Guest</div>

      </div>
      
    )*/
   }
 }
export default Usergreet