import React ,{ Component } from 'react'

class Message extends Component {
    constructor(){
        super()
        this.state = {
            message: 'Welcome family members'
        }
    }
    changeMessage(){
        this.setState({
        message:"Thank You,please come again."
        })
    }
    changeMessage1(){
        this.setState({
        message:"Thankyou for your valuable comments."
        })
    }
    render(){
return (
    <div>
<h1>{this.state.message}</h1>
<button onClick = {()=> this.changeMessage()}>Like</button>   <button onClick = {()=> this.changeMessage1()}>Comment</button>
</div>
)
    }
}
export default Message