import React from 'react'

/*const Greet =  props => {

  console.log(props)
    return (
      <div>
          <h1>
              Hello {props.name} a.k.a {props.Anothername}
          </h1>
        
      </div>
    )
  }*/
  /*const Greet = ({name, Anothername}) => {
  return (
      <div>
          <h1>
              Hello {name} a.k.a {Anothername}
          </h1>
      </div>
  )
  }*/

  const Greet = props => {
      const{name,Anothername} = props
      
      return (
          <div>
              <h1>
                  Hello {name} a.k.a {Anothername}
              </h1>
          </div>
      )
  }


export default Greet