import React , {Component} from 'react'
import './App.css';
import Hello from './components/Hello'
import Parentcomponent from './components/Parentcomponent'
import Usergreet from './components/Usergreet'
import Childcomponent from './components/Childcomponent'
import Counter from './components/Counter'
//function App() {
  class App extends Component{
    render(){
  return (
    <div className="App">
      <Greet  name="Brook" Anothername="Batman"/>
     {/*// <p> This is a most beautiful props </p>
      //<Greet  name="Flower" Anothername="beauty" />
      //<button>Frangance</button>
  // <Greet  name="Lion"  Anothername="King"/>*/}
     {/* <Usergreet />*/}
      {/*<Parentcomponent />*/}
      {/*<Hello />*/}
      </div>
  );
}
  }


export default App;
