import React ,{Component } from 'react'
import './App.css';
import Welcome from './components/Welcome'
import Greet from './components/Greet'
//import Functionclick from './components/Functionclick'
//import Classclick from './components/Classclick'
import Eventbind from './components/Eventbind'
//function App() {
  class App extends Component{
    render(){
  return (
    <div className="App">
       {/*<Functionclick />
      <Classclick />*/}
      
      <Eventbind />
      
     {/*} <Greet  name="Brook" Anothername="Batman"/>
      <p> This is a most beautiful props </p>
      <Greet  name="Flower" Anothername="beauty" />
      <button>Frangance</button>
      <Greet  name="Lion"  Anothername="King"/>
  <Welcome /> */}
    </div>);
}
  }

export default App;