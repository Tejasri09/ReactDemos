import React, { Component } from 'react'

 class Eventbind extends Component {

        constructor(props) {
          super(props)
        
          this.state = {
             message: "Hi"
          }
         // this.clickHandler = this.clickHandler.bind(this)
        }
        //clickHandler() {
          //  this.setState({
            //   message: 'Byee'
            //})
            //console.log(this)
       // }
       clickHandler = () => {
           this.setState({
               message:'Byee'
           })
        
       }
        
  render() {
    return (
      <div>
          <div>{this.state.message}</div>
          {/*<button onClick={this.clickHandler.blind(this)}>Click</button>
        <button onClick={() => this.clickHandler()}>*/}
        <button onClick={this.clickHandler}>Click</button> 
      </div>
    )
    } 
}

export default Eventbind