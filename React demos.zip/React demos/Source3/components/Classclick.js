import React, { Component } from 'react'

 class Classclick extends Component {
     clickHandler() {
         console.log('Click button')
     }
  render() {
    return (
      <div>
        <button onClick={this.clickHandler}> Click Here</button>
      </div>
    )
  }
}

export default Classclick