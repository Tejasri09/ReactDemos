import React from 'react'

const Greet = () => <h1> Hello Theju</h1>

export default Greet