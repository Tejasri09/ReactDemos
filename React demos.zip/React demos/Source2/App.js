import React, { Component } from'react'
import './App.css';
import Greet from './components/Greet'
import Message from './components/Message'
class App extends Component {
  render (){
  return (
    <div className="App">
      <Message />
       {/*<Greet name="Theju" heroname="Super women"/>
       <p>placed in capgemini</p>
       <Greet name ="Rishi" heroname="wonder women"/>
       <p>placed in cts</p>
       <Greet name="Bhagi" heroname="sweetest women"/>
       <button>Action</button>
       <Greet name="kathy" heroname="chubby girl"/>
       <button>action</button>*/}
    </div>
  );
      }
}

export default App;
